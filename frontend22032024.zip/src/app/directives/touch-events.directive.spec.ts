import { TouchEventsDirective } from './touch-events.directive';

describe('TouchEventsDirective', () => {
  it('should create an instance', () => {
    const directive = new TouchEventsDirective();
    expect(directive).toBeTruthy();
  });
});
