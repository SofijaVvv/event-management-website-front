
export interface IRoles {
  id: number;
  name: string;
}
