export interface ItemKomitent {
    id: number
    naziv: string
    pib?: string
    pdvbroj?: string
    adresa?: string
    telefon?: string
    email?: string
    ziroracun?: string
    drzava_combo: {id:number, naziv: string}
    vrstakomitenta_combo: {id:number, naziv: string}
    grad?: string
    napomena?: string
    vrstakomitenta_id: number
    drzava: number

}


export interface ItemSifrarnik {
    id: number
    naziv: string
}


export interface ItemZadatak {
    id: number
    dogadjaj_id: number
    status: number
    opis: string
    vrijeme: string
}



export interface ItemDogadjaj {
    id: number
    datum: string
    vrijeme: string
    komitent_id: number
    vrstadogadjaja_id: number
    iznos: number
    opis: string
    statusdogadjaja_id: number
    komitent: {id:number, naziv: string}
    status: {id:number, naziv: string}
    vrstadogadjaja: {id:number, naziv: string}
    rasporedi: ItemRaspored[]
    zadaci: ItemZadatak[]
    troskovi: ItemTroskovi[]

}


export interface ItemPrihodi {
    id: number
    dogadjaj_id: number
    datum: string
    opis: string
    iznos: number
}


export interface ItemRaspored {
    id: number
    dogadjaj_id: number
    opis: string
    vrijeme: string
}



export interface ItemTroskovi {
    id: number
    dogadjaj_id: number
    datum: string
    opis: string
    iznos: number
    vrstatroska_id: number
    komitent_id: number
    komitent: {id:number, naziv: string}
    vrstatroska: {id:number, naziv: string}
}

export interface ItemStavkeKalendara {
    datum: string
    brojdogadjaja: number
    danunedjelji: number
}

export interface ItemPodaciKalendara {
    tabela: Array<Array<ItemStavkeKalendara>>;
}

export enum StatusDogadjaja {
    Zakazan = 1,
    Zavrsen,
    Rezervisan,
    Otkazan
}
