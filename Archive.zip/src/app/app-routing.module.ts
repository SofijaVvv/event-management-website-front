import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {DomaComponent} from "./komponente/doma/doma.component";
import {LoginComponent} from "./komponente/login/login.component";

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'doma',
    component: DomaComponent
  }



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
