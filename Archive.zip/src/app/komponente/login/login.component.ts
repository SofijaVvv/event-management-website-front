import { Component } from '@angular/core';
import {FormBuilder} from "@angular/forms";
import {ApiPoziviService} from "../../servis/api-pozivi.service";
import {Router} from "@angular/router";
import {AuthService} from "../../servis/auth.service";
import Swal from "sweetalert2";


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.sass']
})
export class LoginComponent {


constructor
(
  private fb: FormBuilder,
  private apiPoziviServis: ApiPoziviService,
  private router: Router,
  private authServis: AuthService
) {}

  formaLogin = this.fb.group({
  username: [''],
  password: [''],
    orm: ['']
});



logovanje(){
  const podaci = JSON.stringify(this.formaLogin.value)
  console.log("prije podatake", podaci)

  this.apiPoziviServis.logovanje(podaci).subscribe((data: any) => {
console.log("povratno:", data)
    if (data.token) {
      this.authServis.upisLokalniStoridz('token', data.token)
      this.router.navigate(['/doma']).then(r => console.log(r))
    } else {
      if (data.token ){

        void Swal.fire({
          title: "Greška",
          html: "Greška u konekciji sa serverom!",
          icon: "error",
          showConfirmButton: false,
          timer: 2000
        })
      } else {

        void Swal.fire({
          title: "Greška",
          html: "Neispravno korisnicko ime, lozinka ili otp",
          icon: "warning",
          showConfirmButton: false,
          timer: 2000
        })
      }
    }



  })
}

}
