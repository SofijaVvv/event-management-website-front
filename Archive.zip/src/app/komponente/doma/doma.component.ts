import { Component } from '@angular/core';

@Component({
  selector: 'app-doma',
  templateUrl: './doma.component.html',
  styleUrls: ['./doma.component.sass']
})
export class DomaComponent {

}
