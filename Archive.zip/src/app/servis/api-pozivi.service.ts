import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {catchError, finalize, Observable, of} from "rxjs";

import Swal from "sweetalert2";
import {AuthService} from "./auth.service";
import {Router} from "@angular/router";

@Injectable({
  providedIn: 'root'
})
export class ApiPoziviService {

  constructor(
    private http: HttpClient,
    private _authServis: AuthService,
    private router: Router,
  ) { }
  jeliUpaljenGlavniMeni = false
  API_SERVIS = 'http://localhost:3000'
  headers = new HttpHeaders({'Content-Type':'application/json; charset=utf-8'});
  public mjeseci = [
    {id: 1, naziv: 'Januar'},
    {id: 2, naziv: 'Februar'},
    {id: 3, naziv: 'Mart'},
    {id: 4, naziv: 'April'},
    {id: 5, naziv: 'Maj'},
    {id: 6, naziv: 'Jun'},
    {id: 7, naziv: 'Jul'},
    {id: 8, naziv: 'Avgust'},
    {id: 9, naziv: 'Septembar'},
    {id: 10, naziv: 'Oktobar'},
    {id: 11, naziv: 'Novembar'},
    {id: 12, naziv: 'Decembar'}
  ]
  public godine = [
    {id: 2023, naziv: '2023'},
    {id: 2024, naziv: '2024'},

  ]

    public listaVremena = [
        {id: 6, naziv: '06:00'},        {id: 7, naziv: '07:00'},
        {id: 8, naziv: '08:00'},        {id: 9, naziv: '09:00'},
        {id: 10, naziv: '10:00'},        {id: 11, naziv: '11:00'},
        {id: 12, naziv: '12:00'},        {id: 13, naziv: '13:00'},
        {id: 14, naziv: '14:00'},        {id: 15, naziv: '15:00'},
        {id: 16, naziv: '16:00'},        {id: 17, naziv: '17:00'},
        {id: 18, naziv: '18:00'},        {id: 19, naziv: '19:00'},
        {id: 20, naziv: '20:00'},        {id: 21, naziv: '21:00'},
        {id: 22, naziv: '22:00'},        {id: 23, naziv: '23:00'},
        {id: 24, naziv: '00:00'}, ]

  odjavaOperatera() {
    Swal.fire({
      title: 'Odjava',
      text: "Da se odjavim iz programa?",
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#8E4585',
      cancelButtonColor: '#4B4B78',
      confirmButtonText: 'Da, odjavi me!',
      cancelButtonText: 'Nazad na program'
    }).then((result) => {
      if (result.isConfirmed) {
        this._authServis.ocistiLokalniStoridz()
        // this.poziviServis.jeliVidljivLijeviMeni = false
        this.router.navigate(['/login'])
        // this.stateService.go('login')
      }
    })

  }

  direktnaOdjavaOperatera() {
    this._authServis.ocistiLokalniStoridz()
    this.router.navigate(['/login'])
  }

  logovanje(loginPodaci:string): Observable<any>{
    const url = this.API_SERVIS + '/login'
    return this.http.post<any>(url,loginPodaci,{headers: this.headers})
      .pipe(catchError((e: any): Observable<any> => {
          return of(e);
        }),
        finalize(() => {
        }));
  }





}
