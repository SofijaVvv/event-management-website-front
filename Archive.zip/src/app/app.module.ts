import {importProvidersFrom, NgModule} from '@angular/core';
import {BrowserModule, HammerModule} from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {HTTP_INTERCEPTORS, HttpClientModule} from "@angular/common/http";
import {InterceptorService} from "./servis/interceptor.service";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatSlideToggleModule} from "@angular/material/slide-toggle";

import {MatNativeDateModule} from "@angular/material/core";
import {NgSelectModule} from "@ng-select/ng-select";
import { JwtModule } from "@auth0/angular-jwt";
import {MatInputModule} from "@angular/material/input";
import {MatDatepickerModule} from "@angular/material/datepicker";
import {MatMenuModule} from "@angular/material/menu";
import {MatIconModule} from "@angular/material/icon";

import { TouchEventsDirective } from './direktive/touch-events.directive';
import {NgChartsModule} from "ng2-charts";
import { LoginComponent } from './komponente/login/login.component';
import { DomaComponent } from './komponente/doma/doma.component';




@NgModule({
  declarations: [
    AppComponent,
    TouchEventsDirective,
    LoginComponent,
    DomaComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatSlideToggleModule,
    MatNativeDateModule,
    NgSelectModule,
    HammerModule,
    JwtModule.forRoot({
      config: {
        tokenGetter: function tokenGetter() {
          return localStorage.getItem('token');
        }
      }
    }),
    MatInputModule,
    MatDatepickerModule,
    MatMenuModule,
    MatIconModule,
    NgChartsModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: InterceptorService,
      multi: true
    },
    importProvidersFrom(HammerModule)

  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
